import test from 'node:test';
import assert from 'node:assert/strict';
import {reviewModal} from '../src/blocks.mjs';
const row={id:'test',sender_name:'작성자',recipient_name:'수신자',sender_team:'A',recipient_team:'B',body:'테스트 칭찬 내용',month:'2026-10-01',core_value:'growth',status:'pending'};
test('admin can read own pending praise without decision buttons',()=>{
 const view=reviewModal({rows:[{...row,can_review:false}]});
 assert(JSON.stringify(view).includes(row.body));
 assert(JSON.stringify(view).includes('다른 피플팀 관리자'));
 assert(!view.blocks.some(b=>b.elements?.some(e=>['approve_open','reject_open'].includes(e.action_id))));
});
test('unrelated pending praise retains decisions and completed praise is read only',()=>{
 const view=reviewModal({rows:[{...row,can_review:true}]});
 assert.equal(view.blocks.flatMap(b=>b.elements??[]).filter(e=>['approve_open','reject_open'].includes(e.action_id)).length,2);
 const completed=reviewModal({rows:[{...row,status:'approved',can_review:false}]});
 assert(JSON.stringify(completed).includes('처리 상태: 승인'));
 assert(!completed.blocks.flatMap(b=>b.elements??[]).some(e=>['approve_open','reject_open'].includes(e.action_id)));
});
