export const VALUES = [
  ['breakthrough','막힘없는 해결사! · 돌파','새로운 방법으로 막힌 문제를 풀어줬어요'],
  ['altruism','동료의 든든한 지원군! · 이타심','다른 팀의 어려움도 자기 일처럼 도와줬어요'],
  ['right_choice','원칙 지킴이! · 옳은 선택','번거롭더라도 사실과 원칙에 따라 판단했어요'],
  ['optimization','비효율 해결사! · 최적화','반복되는 불편을 줄이고 일의 흐름을 개선했어요'],
  ['growth','프로학습러! · 성장','꾸준히 배우고 새로운 방법을 업무에 적용했어요'],
  ['ownership','책임감 만렙! · 오너십','맡은 일의 결과를 끝까지 확인하고 책임졌어요']
];
const plain = text => ({type:'plain_text',text});
const section = text => ({type:'section',text:plain(text)});
const button = (text, action_id, value) => ({type:'button',text:plain(text),action_id,...(value ? {value}: {})});
export function homeView(data) {
  const status={pending:'검토 대기',approved:'승인',rejected:'반려'}[data.status]??'없음';
  const blocks = [
    {type:'header',text:plain('바로고 THANK YOU')},
    section('함께여서 가능했던 순간, 마음에 남은 동료의 도움.\n그 고마움을 작은 칭찬으로 남겨주세요. 💛'),
    section('한 달에 한 번, 다른 팀 동료에게 감사의 마음을 전할 수 있어요.\n남겨주신 이야기는 피플팀이 소중히 살펴봅니다. 공개 채널에 게시되거나 동료에게 자동으로 전달되지는 않아요.'),
    {type:'divider'},
    section(`이번 달 칭찬 ${data.test_quota_available ? '테스트용으로 한 번 더 남길 수 있어요' : data.submitted ? '✓ 제출 완료' : '아직 전하지 않았어요'}${data.submitted ? ` · ${status}` : ''}`),
    section(`이번 분기 내가 남긴 칭찬  ${data.quarter_sent??0}건\n이번 분기 내가 받은 칭찬  ${data.quarter_received??0}건`),
    {type:'context',elements:[plain('남긴 칭찬은 접수 건수, 받은 칭찬은 피플팀이 승인한 건수예요. 분기는 1~3월 · 4~6월 · 7~9월 · 10~12월 기준입니다.')]}
  ];
  const canSubmit=data.eligible && !data.submitted;
  blocks.push({type:'actions',elements:[canSubmit?{...button('칭찬하기','praise_open'),style:'primary'}:button('🔒 칭찬하기','praise_unavailable')]});
  if(data.submitted) blocks.push({type:'context',elements:[plain('이번 달 칭찬을 이미 남겼어요. 다음 달에 다시 참여할 수 있어요.')]});
  if (!data.eligible) blocks.push(section('직원·팀 정보가 등록되지 않았습니다. 피플팀에 문의해주세요.'));
  blocks.push({type:'actions',elements:[button('내 현황 새로고침','home_refresh')]});
  if (data.admin) blocks.push({type:'divider'},{type:'actions',elements:[button('비공개 검토함','review_open'),button('이번 분기 점수','scores_open')]});
  return {type:'home',blocks};
}
export function praiseModal() {
  return {type:'modal',callback_id:'praise_submit',title:plain('동료 칭찬하기'),submit:plain('비공개 접수'),close:plain('취소'),blocks:[
    section('피플팀이 검토합니다. 공개 게시·수신자 알림은 없습니다. 제출 후 이번 달에는 다시 제출할 수 없습니다.'),
    section('불필요한 개인정보, 건강·가족 정보 등 민감한 내용은 입력하지 마세요.'),
    {type:'input',block_id:'recipient',label:plain('칭찬할 다른 팀 동료'),element:{type:'users_select',action_id:'value'}},
    {type:'input',block_id:'value',label:plain('핵심가치'),element:{type:'static_select',action_id:'value',options:VALUES.map(([value,label,desc])=>({text:plain(label),value,description:plain(desc)}))}},
    {type:'input',block_id:'body',label:plain('어떤 행동이 고마웠나요?'),hint:plain('구체적인 상황과 행동을 20~2,000자로 작성해주세요.'),element:{type:'plain_text_input',action_id:'value',multiline:true,min_length:20,max_length:2000}}
  ]};
}
export function reviewModal(data) {
  const filters=[['all','전체'],['pending','검토 대기'],['approved','승인'],['rejected','반려']].map(([value,text])=>({text:plain(text),value}));
  const blocks = [section('피플팀 전용 · 모든 접수 내역을 확인할 수 있어요.\n내가 작성했거나 받은 칭찬은 조회만 가능하며, 승인·반려는 다른 피플팀 관리자가 담당합니다.'),
    section(`전체 ${data.total??data.rows.length}건 · 대기 ${data.pending??0}건 · 승인 ${data.approved??0}건 · 반려 ${data.rejected??0}건\n최신 접수순 · 한 번에 5건씩 표시`),
    {type:'actions',elements:[{type:'static_select',action_id:'review_filter',options:filters,initial_option:filters.find(x=>x.value===(data.filter??'all'))},button('CSV 내보내기','export_open',data.filter??'all')]}];
  for (const row of data.rows) blocks.push(
    {type:'divider'}, section(`발신: ${row.sender_name} → 수신: ${row.recipient_name}\n${row.sender_team} → ${row.recipient_team}\n${row.month} · ${VALUES.find(v=>v[0]===row.core_value)?.[1]??row.core_value}`),
    section(row.body),
    section(`처리 상태: ${{pending:'검토 대기',approved:'승인',rejected:'반려'}[row.status]??'검토 대기'}`),
    ...(row.can_review===true
      ? [{type:'actions',elements:[button('승인','approve_open',row.id),button('반려','reject_open',row.id)]}]
      : [section(row.status==='pending'?'조회 전용 · 내가 작성했거나 받은 칭찬은 다른 피플팀 관리자가 승인·반려합니다.':'조회 전용 · 이미 처리된 칭찬입니다.')])
  );
  if (!data.rows.length) blocks.push(section('접수된 칭찬이 없습니다.'));
  const navigation=[];
  if (data.next) navigation.push(button('다음 5건','review_next',JSON.stringify({cursor:data.next,filter:data.filter??'all'})));
  navigation.push(button('처음으로','review_first',data.filter??'all'));
  blocks.push({type:'actions',elements:navigation});
  return {type:'modal',title:plain('비공개 검토함'),close:plain('닫기'),blocks};
}
export function decisionModal(id, decision) {
  return {type:'modal',callback_id:'review_submit',private_metadata:JSON.stringify({id,decision}),title:plain(decision==='approved'?'칭찬 승인':'칭찬 반려'),submit:plain('확정'),close:plain('취소'),blocks:[section('확정 후 직접 변경할 수 없습니다. 잘못 처리한 경우 운영 담당자에게 문의해주세요.'),{type:'input',block_id:'reason',label:plain('검토 사유 (피플팀 내부용)'),element:{type:'plain_text_input',action_id:'value',multiline:true,min_length:2,max_length:500}}]};
}
export function messageModal(text) {
  return {type:'modal',title:plain('바로고 THANK YOU'),close:plain('닫기'),blocks:[section(text)]};
}
