export const VALUES = [
  ['breakthrough','막힘없는 해결사! · 돌파','새로운 방법으로 막힌 문제를 풀어줬어요'],
  ['altruism','동료의 든든한 지원군! · 이타심','다른 팀의 어려움도 자기 일처럼 도와줬어요'],
  ['right_choice','원칙 지킴이! · 옳은 선택','번거롭더라도 사실과 원칙에 따라 판단했어요'],
  ['optimization','비효율 해결사! · 최적화','반복되는 불편을 줄이고 일의 흐름을 개선했어요'],
  ['growth','프로학습러! · 성장','꾸준히 배우고 새로운 방법을 업무에 적용했어요'],
  ['ownership','책임감 만렙! · 오너십','맡은 일의 결과를 끝까지 확인하고 책임졌어요']
];
export const PARTICIPATION_RULE = "같은 동료에게는 분기당 한 번만 칭찬할 수 있어요.\n점수를 위해 미리 약속하고 칭찬을 주고받는 일을 줄이고, 더 다양한 동료의 좋은 행동을 발견하기 위한 규칙이에요. 실제로 고마웠던 일이 있다면 서로 칭찬하는 것은 괜찮아요.";
const participationNotes = '참여 전 확인해주세요\n- 한 달에 한 번, 다른 팀 동료에게 칭찬을 맡길 수 있어요. 제출하면 이번 달 참여가 완료돼요.\n- 같은 동료에게는 분기당 한 번만 칭찬할 수 있어요.\n- 점수를 위해 미리 약속한 맞칭찬은 지양해주세요. 실제로 고마웠던 일이 있다면 서로 칭찬하는 것은 괜찮아요.\n- 더 다양한 동료의 좋은 행동을 발견하고 칭찬해주세요.\n- 남긴 이야기는 피플팀만 확인하며, 공개 게시·수신자 자동 알림은 없어요.\n- 불필요한 개인정보나 건강·가족 정보 등 민감한 내용은 적지 말아주세요.';
const plain = text => ({type:'plain_text',text});
const section = text => ({type:'section',text:plain(text)});
const button = (text, action_id, value) => ({type:'button',text:plain(text),action_id,...(value ? {value}: {})});
export function homeView(data) {
  const status='접수 완료';
  const blocks = [
    {type:'header',text:plain('칭찬교환소')},
    section('칭찬교환소에 오신 걸 환영해요! 💛'),
    section('동료에게 받은 고마움, 칭찬으로.\n동료에게 받은 칭찬, 팀의 간식으로. 🍪'),
    section('함께 일하며 고마웠던 동료의 행동을 남겨주세요.\n맡겨주신 이야기는 바로 접수되고, 분기 평가에 반영돼요.'),
    {type:'divider'},
    section(`이번 달 칭찬 ${data.test_quota_available ? '테스트용으로 한 번 더 남길 수 있어요' : data.submitted ? '✓ 제출 완료' : '아직 전하지 않았어요'}${data.submitted ? ` · ${status}` : ''}`),
    section(`이번 분기 내가 남긴 칭찬  ${data.quarter_sent??0}건\n이번 분기 내가 받은 칭찬  ${data.quarter_received??0}건`),
    {type:'context',elements:[plain('남긴 칭찬과 받은 칭찬 모두 전체 접수 건수예요. 분기는 1~3월 · 4~6월 · 7~9월 · 10~12월 기준입니다.')]}
  ];
  const canSubmit=data.eligible && !data.submitted;
  blocks.push({type:'actions',elements:[canSubmit?{...button('칭찬 맡기기','praise_open'),style:'primary'}:button('🔒 칭찬 맡기기','praise_unavailable')]});
  if(data.submitted) blocks.push({type:'context',elements:[plain('이번 달 칭찬을 이미 남겼어요. 다음 달에 다시 참여할 수 있어요.')]});
  if (!data.eligible) blocks.push(section('직원·팀 정보가 등록되지 않았습니다. 피플팀에 문의해주세요.'));
  blocks.push({type:'actions',elements:[button('내 현황 새로고침','home_refresh')]});
  blocks.push({type:'divider'},section(participationNotes),section('간식 선물 안내\n- 분기별 선정자의 팀에 간식을 선물해요.\n- 칭찬 접수마다 간식이 지급되는 방식은 아니에요.'));
  if (data.admin) blocks.push({type:'divider'},{type:'actions',elements:[button('비공개 접수함','review_open'),button('이번 분기 점수','scores_open')]});
  return {type:'home',blocks};
}
export function praiseModal() {
  return {type:'modal',callback_id:'praise_submit',title:plain('칭찬 맡기기'),submit:plain('비공개로 맡기기'),close:plain('취소'),blocks:[
    section('반가워요! 고마운 동료의 이야기를 맡겨주세요. 💛\n누구의 어떤 행동이 고마웠는지 적어주세요. 제출하면 바로 접수돼요.'),
    {type:'input',block_id:'recipient',label:plain('칭찬할 다른 팀 동료'),element:{type:'users_select',action_id:'value'}},
    {type:'input',block_id:'value',label:plain('핵심가치'),element:{type:'static_select',action_id:'value',options:VALUES.map(([value,label,desc])=>({text:plain(label),value,description:plain(desc)}))}},
    {type:'input',block_id:'body',label:plain('어떤 행동이 고마웠나요?'),hint:plain('육하원칙을 참고해 ‘어떤 상황에서 → 동료가 무엇을 어떻게 했고 → 어떤 도움이 되었는지’를 적어주세요. 선택한 핵심가치와 연결되는 구체적인 행동이 잘 드러날수록 좋아요. 길이보다 내용이 중요해요! (20~2,000자)'),element:{type:'plain_text_input',action_id:'value',multiline:true,min_length:20,max_length:2000}},
    {type:'divider'},section(participationNotes)
  ]};
}
export function reviewModal(data) {
  const blocks = [section('피플팀 전용 · 전체 접수 내역을 조회하고 CSV로 내려받을 수 있어요.\n제출 즉시 접수되며 승인·반려 절차는 없어요. 내용의 충실도는 분기 정성 평가에서 판단해요.'),
    section(`전체 ${data.total??data.rows.length}건 · 최신 접수순 · 한 번에 5건씩 표시`),
    {type:'actions',elements:[button('CSV 내보내기','export_open','all')]}];
  for (const row of data.rows) blocks.push(
    {type:'divider'}, section(`발신: ${row.sender_name} → 수신: ${row.recipient_name}\n${row.sender_team} → ${row.recipient_team}\n${row.month} · ${VALUES.find(v=>v[0]===row.core_value)?.[1]??row.core_value}`),
    section(row.body),section('접수 완료 · 조회 전용')
  );
  if (!data.rows.length) blocks.push(section('접수된 칭찬이 없습니다.'));
  const navigation=[];
  if (data.next) navigation.push(button('다음 5건','review_next',JSON.stringify({cursor:data.next,filter:'all'})));
  navigation.push(button('처음으로','review_first','all'));
  blocks.push({type:'actions',elements:navigation});
  return {type:'modal',title:plain('비공개 접수함'),close:plain('닫기'),blocks};
}
export function messageModal(text) {
  return {type:'modal',title:plain('칭찬교환소'),close:plain('닫기'),blocks:[section(text)]};
}
