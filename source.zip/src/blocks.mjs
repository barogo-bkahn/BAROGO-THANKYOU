export const VALUES = [
  ['breakthrough','Breakthrough · 돌파','한계를 깨고 새로운 길을 만드는 태도'],
  ['altruism','Altruism · 이타심','함께 성장하고 서로를 돕는 태도'],
  ['right_choice','Right Choice · 옳은 선택','쉬움보다 옳음을 기준으로 선택하는 태도'],
  ['optimization','Optimization · 최적화','부분이 아닌 전체 흐름을 끝까지 최적화하는 태도'],
  ['growth','Growth · 성장','어제보다 나은 오늘을 만드는 학습 문화'],
  ['ownership','Ownership · 오너십','맡은 일의 결과를 끝까지 책임지는 태도']
];
const plain = text => ({type:'plain_text',text});
const section = text => ({type:'section',text:plain(text)});
const button = (text, action_id, value) => ({type:'button',text:plain(text),action_id,...(value ? {value}: {})});
export function homeView(data) {
  const status={pending:'검토 대기',approved:'승인',rejected:'반려'}[data.status]??'없음';
  const blocks = [
    {type:'header',text:plain('바로고 THANK YOU')},
    section('함께 일하며 고마웠던 다른 팀 동료에게 칭찬을 남겨주세요.'),
    section('월 1회 제출할 수 있습니다. 내용은 People팀만 검토하며 공개 채널이나 수신자에게 자동 전달되지 않습니다.'),
    section(`이번 달: ${data.submitted ? '제출 완료' : '아직 제출하지 않았어요'} · 내 제출 상태: ${status}`)
  ];
  if (data.eligible && !data.submitted) blocks.push({type:'actions',elements:[button('칭찬하기','praise_open')]});
  if (!data.eligible) blocks.push(section('직원·팀 정보가 등록되지 않았습니다. People팀에 문의해주세요.'));
  if (data.admin) blocks.push({type:'divider'},{type:'actions',elements:[button('비공개 검토함','review_open'),button('이번 분기 점수','scores_open')]});
  return {type:'home',blocks};
}
export function praiseModal() {
  return {type:'modal',callback_id:'praise_submit',title:plain('동료 칭찬하기'),submit:plain('비공개 접수'),close:plain('취소'),blocks:[
    section('People팀이 검토합니다. 공개 게시·수신자 알림은 없습니다. 제출 후 이번 달에는 다시 제출할 수 없습니다.'),
    section('불필요한 개인정보, 건강·가족 정보 등 민감한 내용은 입력하지 마세요.'),
    {type:'input',block_id:'recipient',label:plain('칭찬할 다른 팀 동료'),element:{type:'users_select',action_id:'value'}},
    {type:'input',block_id:'value',label:plain('핵심가치'),element:{type:'static_select',action_id:'value',options:VALUES.map(([value,label,desc])=>({text:plain(label),value,description:plain(desc)}))}},
    {type:'input',block_id:'body',label:plain('어떤 행동이 고마웠나요?'),hint:plain('구체적인 상황과 행동을 20~2,000자로 작성해주세요.'),element:{type:'plain_text_input',action_id:'value',multiline:true,min_length:20,max_length:2000}}
  ]};
}
export function reviewModal(data) {
  const blocks = [section('People팀 전용 · 본인 발신/수신 건은 다른 관리자가 검토합니다.')];
  for (const row of data.rows) blocks.push(
    {type:'divider'}, section(`발신: ${row.sender_name} → 수신: ${row.recipient_name}\n${row.sender_team} → ${row.recipient_team}\n${row.month} · ${row.core_value}`),
    section(row.body),
    section(`처리 상태: ${{pending:'검토 대기',approved:'승인',rejected:'반려'}[row.status]??'검토 대기'}`),
    ...(row.can_review===true
      ? [{type:'actions',elements:[button('승인','approve_open',row.id),button('반려','reject_open',row.id)]}]
      : [section(row.status==='pending'?'조회 전용 · 본인 발신/수신 건은 다른 관리자가 처리합니다.':'조회 전용 · 이미 처리된 칭찬입니다.')])
  );
  if (!data.rows.length) blocks.push(section('접수된 칭찬이 없습니다.'));
  if (data.next) blocks.push({type:'actions',elements:[button('다음 5건','review_next',data.next)]});
  return {type:'modal',title:plain('비공개 검토함'),close:plain('닫기'),blocks};
}
export function decisionModal(id, decision) {
  return {type:'modal',callback_id:'review_submit',private_metadata:JSON.stringify({id,decision}),title:plain(decision==='approved'?'칭찬 승인':'칭찬 반려'),submit:plain('확정'),close:plain('취소'),blocks:[section('확정 후 직접 변경할 수 없습니다. 잘못 처리한 경우 운영 담당자에게 문의해주세요.'),{type:'input',block_id:'reason',label:plain('검토 사유 (People팀 내부용)'),element:{type:'plain_text_input',action_id:'value',multiline:true,min_length:2,max_length:500}}]};
}
export function messageModal(text) {
  return {type:'modal',title:plain('바로고 THANK YOU'),close:plain('닫기'),blocks:[section(text)]};
}
